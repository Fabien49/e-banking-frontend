package com.fabienit.bibliobatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliobatchApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.fabienit.biblioapi;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BiblioApiApplication implements CommandLineRunner{


	public static void main(String[] args) {

		SpringApplication.run(BiblioApiApplication.class, args);
	}

	public void run(String... args) throws Exception{
		}

}

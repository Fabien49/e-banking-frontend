package com.fabienit.bibliowebv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bibliowebv2Application {

	public static void main(String[] args) {
		SpringApplication.run(Bibliowebv2Application.class, args);
	}

}

package com.fabienit.batchBiblio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BatchBiblioApplicationTests {

	@Test
	void contextLoads() {
	}

}

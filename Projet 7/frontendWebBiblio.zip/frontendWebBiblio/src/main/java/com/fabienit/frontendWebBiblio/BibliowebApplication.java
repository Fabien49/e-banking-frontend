package com.fabienit.frontendWebBiblio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BibliowebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BibliowebApplication.class, args);
	}

}

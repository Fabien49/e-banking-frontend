package com.fabienit.frontendWebBiblio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontendWebBiblioApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontendWebBiblioApplication.class, args);
	}

}

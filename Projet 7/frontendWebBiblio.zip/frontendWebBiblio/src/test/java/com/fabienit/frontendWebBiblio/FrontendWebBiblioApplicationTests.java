package com.fabienit.frontendWebBiblio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontendWebBiblioApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.fabienit.biblioweb.biblioweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliowebApplicationTests {

	@Test
	void contextLoads() {
	}

}

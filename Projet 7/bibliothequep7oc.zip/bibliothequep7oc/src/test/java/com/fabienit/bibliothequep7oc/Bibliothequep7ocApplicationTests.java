package com.fabienit.bibliothequep7oc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bibliothequep7ocApplicationTests {

	@Test
	void contextLoads() {
	}

}

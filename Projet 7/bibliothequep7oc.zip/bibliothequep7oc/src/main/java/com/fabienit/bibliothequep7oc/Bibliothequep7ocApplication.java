package com.fabienit.bibliothequep7oc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bibliothequep7ocApplication {

	public static void main(String[] args) {
		SpringApplication.run(Bibliothequep7ocApplication.class, args);
	}

}

package com.fabienit.backendRestApiBiblio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendRestApiBiblioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackendRestApiBiblioApplication.class, args);
	}

}

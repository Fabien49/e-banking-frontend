package com.fabienit.backendRestApiBiblio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendRestApiBiblioApplicationTests {

	@Test
	void contextLoads() {
	}

}

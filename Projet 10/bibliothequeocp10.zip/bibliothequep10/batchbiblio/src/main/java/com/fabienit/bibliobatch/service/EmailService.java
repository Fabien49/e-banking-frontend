package com.fabienit.bibliobatch.service;

/**
 * EmailService
 */
public interface EmailService {

    
}
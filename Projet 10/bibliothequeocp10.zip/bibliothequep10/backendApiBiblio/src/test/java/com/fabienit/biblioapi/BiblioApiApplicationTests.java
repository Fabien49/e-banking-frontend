package com.fabienit.biblioapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BiblioApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

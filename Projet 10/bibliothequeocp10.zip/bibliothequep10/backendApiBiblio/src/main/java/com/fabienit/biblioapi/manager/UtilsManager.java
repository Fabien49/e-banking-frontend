package com.fabienit.biblioapi.manager;

/**
 * UtilsManager
 */
public interface UtilsManager {

    String[] splitQueryString(String query);

}